"""
AirPiano — Main Entry Point
Ties together all modules: hand tracking, piano engine, sound engine, UI renderer, recorder.
"""

import os
import sys
import time

import cv2
import numpy as np

from config import (
    FRAME_WIDTH, FRAME_HEIGHT, FPS_TARGET, SOUNDS_DIR,
    PRESS_VELOCITY_THRESHOLD, INSTRUMENTS
)
from hand_tracker import HandTracker
from piano_engine import PianoEngine
from sound_engine import SoundEngine
from ui_renderer import UIRenderer
from recorder import Recorder
from generate_sounds import generate_all_instruments


def ensure_sounds_exist():
    """Generate sounds if they don't exist yet."""
    piano_dir = SOUNDS_DIR / "piano"
    if not piano_dir.exists() or len(list(piano_dir.glob("*.wav"))) < 37:
        print("[AirPiano] First run detected — generating sound samples...")
        generate_all_instruments()
        print("[AirPiano] Sound generation complete!")
    else:
        print("[AirPiano] Sound samples found.")


def main():
    """Main application loop."""
    print("=" * 55)
    print("  ✦  A I R P I A N O  ✦")
    print("  Premium Gesture-Controlled Piano")
    print("=" * 55)
    print()

    # ─── Step 1: Ensure sounds exist ───
    ensure_sounds_exist()

    # ─── Step 2: Initialize modules ───
    print("[AirPiano] Initializing modules...")

    tracker = HandTracker()
    piano = PianoEngine()
    sound = SoundEngine()
    renderer = UIRenderer()
    recorder = Recorder()

    # Load default instrument sounds
    if sound.is_initialized:
        sound.load_sounds("Piano")
    else:
        print("[AirPiano] WARNING: Audio system not available. Continuing without sound.")

    # ─── Step 3: Open webcam ───
    print("[AirPiano] Opening camera...")
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("[AirPiano] ERROR: Could not open camera!")
        print("[AirPiano] Make sure a webcam is connected and not in use by another app.")
        sys.exit(1)

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)

    # Get actual frame dimensions
    actual_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    actual_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    print(f"[AirPiano] Camera resolution: {actual_w}x{actual_h}")

    # Compute key zones with actual frame size
    piano.compute_key_zones(actual_w, actual_h)

    # ─── FPS tracking ───
    fps = 0.0
    frame_count = 0
    fps_timer = time.time()

    # ─── Gesture cooldowns ───
    last_pinch_time = 0.0
    pinch_cooldown = 0.8  # seconds
    last_fist_time = 0.0
    fist_cooldown = 0.5

    print("[AirPiano] Ready! Press ESC to quit.")
    print()

    # ─── Step 4: Main loop ───
    try:
        while True:
            ret, frame = cap.read()
            if not ret or frame is None:
                continue

            # Mirror for natural interaction
            frame = cv2.flip(frame, 1)
            h, w = frame.shape[:2]

            # ─── Step 5: Process hands ───
            hands = tracker.process(frame)

            # ─── Step 6: Collect all fingertips with velocity ───
            all_fingertips = []
            for hand in hands:
                hand_idx = hand["hand_index"]
                for finger_name, (px, py) in hand["fingertips"].items():
                    # Skip thumb for playing (it's used for gestures)
                    if finger_name == "THUMB":
                        continue
                    dx, dy = tracker.get_fingertip_velocity(hand_idx, finger_name, (px, py))
                    all_fingertips.append((px, py, dy, finger_name, hand_idx))

            # ─── Step 7: Check for key presses ───
            pressed_notes = piano.check_press(all_fingertips, h)

            # ─── Step 8: Play sounds + log ───
            for note, velocity in pressed_notes:
                sound.play_note(note, velocity)
                if recorder.recording:
                    recorder.log_note(note, velocity)

            # ─── Step 9: Gesture handling ───
            current_time = time.time()
            for hand in hands:
                # Pinch = octave shift
                if tracker.is_pinch(hand) and current_time - last_pinch_time > pinch_cooldown:
                    if hand["handedness"] == "Left":
                        piano.shift_octave(-1)
                    else:
                        piano.shift_octave(1)
                    last_pinch_time = current_time

                # Open palm = sustain on
                if tracker.is_open_palm(hand):
                    sound.set_sustain(True)

                # Fist = sustain off
                if tracker.is_fist(hand) and current_time - last_fist_time > fist_cooldown:
                    sound.set_sustain(False)
                    last_fist_time = current_time

            # ─── Update piano animation ───
            piano.update(1.0 / max(fps, 1.0))

            # ─── Step 10: Build state dict ───
            state = {
                'octave': piano.octave,
                'volume': sound.volume,
                'instrument': sound.instrument,
                'sustain': sound.sustain,
                'recording': recorder.recording,
                'rec_elapsed_ms': recorder.elapsed_ms,
                'rec_events': recorder.event_count,
                'playing_back': recorder.is_playing_back,
                'hands_count': len(hands),
                'active_notes': sound.active_notes,
                'error_message': sound.error_message,
            }

            # ─── Step 10: Render everything ───
            frame = renderer.render(frame, hands, piano.keys, pressed_notes, fps, state)

            # ─── Step 11: Keyboard controls ───
            key = cv2.waitKey(1) & 0xFF

            if key == 27:  # ESC
                print("[AirPiano] Quitting...")
                break

            elif key == ord('r') or key == ord('R'):
                if recorder.recording:
                    recorder.stop_recording()
                else:
                    recorder.start_recording()

            elif key == ord('p') or key == ord('P'):
                if not recorder.recording and not recorder.is_playing_back:
                    recorder.playback(sound)

            elif key == ord('m') or key == ord('M'):
                if not recorder.recording:
                    path = recorder.export_midi()
                    if path:
                        print(f"[AirPiano] MIDI saved: {path}")

            elif key == ord('j') or key == ord('J'):
                if not recorder.recording:
                    path = recorder.export_json()
                    if path:
                        print(f"[AirPiano] JSON saved: {path}")

            elif key == 0:  # Up arrow
                piano.shift_octave(1)

            elif key == 1:  # Down arrow
                piano.shift_octave(-1)

            elif key == ord('1'):
                sound.set_instrument("Piano")

            elif key == ord('2'):
                sound.set_instrument("Marimba")

            elif key == ord('3'):
                sound.set_instrument("Organ")

            elif key == ord('v') or key == ord('V'):
                sound.volume_up()

            elif key == ord('b') or key == ord('B'):
                sound.volume_down()

            # ─── Step 12: Display frame ───
            cv2.imshow("AirPiano", frame)

            # ─── FPS calculation ───
            frame_count += 1
            elapsed = time.time() - fps_timer
            if elapsed >= 1.0:
                fps = frame_count / elapsed
                frame_count = 0
                fps_timer = time.time()

    except KeyboardInterrupt:
        print("\n[AirPiano] Interrupted by user.")

    finally:
        # Cleanup
        print("[AirPiano] Cleaning up...")
        cap.release()
        cv2.destroyAllWindows()
        tracker.release()
        sound.cleanup()
        print("[AirPiano] Goodbye!")


if __name__ == "__main__":
    main()
